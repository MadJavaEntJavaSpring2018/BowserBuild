$(document).ready(function () {

    var date = new Date().getFullYear();

    $('#date').append(date);

});